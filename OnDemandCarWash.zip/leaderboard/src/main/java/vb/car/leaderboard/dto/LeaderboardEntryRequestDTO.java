package vb.car.leaderboard.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/*(Useful if we ever want to allow manual entry or sync.)*/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LeaderboardEntryRequestDTO {
	private Long userId;
	private String username;
	private Integer totalReviews;
	private Double averageRating;
}
