package vb.car.leaderboard.service;

import java.util.List;

import vb.car.leaderboard.dto.LeaderboardEntryRequestDTO;
import vb.car.leaderboard.dto.LeaderboardEntryResponseDTO;

public interface LeaderboardService {
	
	LeaderboardEntryResponseDTO addOrUpdateEntry(LeaderboardEntryRequestDTO requestDTO);
	
	List<LeaderboardEntryResponseDTO> getTopByTotalReviews();
	
	List<LeaderboardEntryResponseDTO> getTopByAverageRating();
	
	LeaderboardEntryResponseDTO getUserById(Long userId);

	void deleteEntry(Long userId);
	
}
