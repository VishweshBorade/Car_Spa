package vb.car.leaderboard.exception;

public class EntryNotFoundException extends RuntimeException {
	public EntryNotFoundException(String message) {
		super(message);
	}
}
