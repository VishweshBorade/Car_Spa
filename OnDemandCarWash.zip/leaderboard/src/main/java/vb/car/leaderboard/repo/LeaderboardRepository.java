package vb.car.leaderboard.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import vb.car.leaderboard.entity.LeaderboardEntry;

@Repository
public interface LeaderboardRepository extends JpaRepository<LeaderboardEntry, Long> {
	List<LeaderboardEntry> findTop10ByOrderByTotalReviewsDesc();
	List<LeaderboardEntry> findTop10ByOrderByAverageRatingDesc();
	List<LeaderboardEntry> findByUserId(Long userId);
}
