package vb.car.leaderboard.service;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import vb.car.leaderboard.dto.LeaderboardEntryRequestDTO;
import vb.car.leaderboard.dto.LeaderboardEntryResponseDTO;
import vb.car.leaderboard.entity.LeaderboardEntry;
import vb.car.leaderboard.exception.EntryNotFoundException;
import vb.car.leaderboard.repo.LeaderboardRepository;

@Service
@RequiredArgsConstructor
public class LeaderboardServiceImpl implements LeaderboardService {
	
	private final LeaderboardRepository repo;
	
	@Override
	public LeaderboardEntryResponseDTO addOrUpdateEntry(LeaderboardEntryRequestDTO dto) {
		LeaderboardEntry entry = repo.findByUserId(dto.getUserId()).stream().findFirst().orElse(null);
		
		if(entry == null) {
			entry = LeaderboardEntry.builder()
					.userId(dto.getUserId())
					.username(dto.getUsername())
					.totalReviews(dto.getTotalReviews())
					.averageRating(dto.getAverageRating())
					.build();
			
		}
		else {
			entry.setTotalReviews(dto.getTotalReviews());
			entry.setAverageRating(dto.getAverageRating());
			entry.setUsername(dto.getUsername());
		}
		
		LeaderboardEntry saved = repo.save(entry);
		return mapToResponse(saved);
	}

	@Override
	public List<LeaderboardEntryResponseDTO> getTopByTotalReviews() {
		return repo.findTop10ByOrderByTotalReviewsDesc().stream().map(this::mapToResponse).toList();
	}

	@Override
	public List<LeaderboardEntryResponseDTO> getTopByAverageRating() {
		return repo.findTop10ByOrderByAverageRatingDesc().stream().map(this::mapToResponse).toList();
	}

	@Override
	public LeaderboardEntryResponseDTO getUserById(Long userId) {
		LeaderboardEntry entry = repo.findByUserId(userId).stream().findFirst().orElseThrow(()-> new EntryNotFoundException("Leaderboardentry not found for user id : "+userId));
		return mapToResponse(entry);
	}
	
	@Override
	public void deleteEntry(Long userId) {
		LeaderboardEntry entry = repo.findByUserId(userId).stream().findFirst().orElseThrow(()-> new EntryNotFoundException("Leaderboard entry not found for user ID: "+ userId));
		
		repo.delete(entry);
		
	}
	
	private LeaderboardEntryResponseDTO mapToResponse(LeaderboardEntry entry) {
        return LeaderboardEntryResponseDTO.builder()
                .userId(entry.getUserId())
                .username(entry.getUsername())
                .totalReviews(entry.getTotalReviews())
                .averageRating(entry.getAverageRating())
                .build();
    }

	

}
