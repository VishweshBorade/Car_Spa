package vb.car.leaderboard.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import vb.car.leaderboard.dto.LeaderboardEntryRequestDTO;
import vb.car.leaderboard.dto.LeaderboardEntryResponseDTO;
import vb.car.leaderboard.service.LeaderboardService;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping("/leaderboard")
@RequiredArgsConstructor
public class LeaderboardController {
	private final LeaderboardService service;
	
	@PostMapping("/add")
	public ResponseEntity<LeaderboardEntryResponseDTO> addEntry(@RequestBody LeaderboardEntryRequestDTO dto){
		return ResponseEntity.ok(service.addOrUpdateEntry(dto));
	}
	
	@PutMapping("/update")
	public ResponseEntity<LeaderboardEntryResponseDTO> updateEntry(@RequestBody LeaderboardEntryRequestDTO dto){
		return ResponseEntity.ok(service.addOrUpdateEntry(dto));
	}
	
	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<String> deleteEntry(@PathVariable Long userId){
		service.deleteEntry(userId);
		return ResponseEntity.ok("Leaderboard entry deleted successfully");
	}
	
    @GetMapping("/top/reviews")
    public ResponseEntity<List<LeaderboardEntryResponseDTO>> getTopByReviews() {
        return ResponseEntity.ok(service.getTopByTotalReviews());
    }

    @GetMapping("/top/ratings")
    public ResponseEntity<List<LeaderboardEntryResponseDTO>> getTopByRatings() {
        return ResponseEntity.ok(service.getTopByAverageRating());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<LeaderboardEntryResponseDTO> getByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(service.getUserById(userId));
    }
}
