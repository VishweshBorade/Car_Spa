package vb.car.notification.service;

import vb.car.notification.dto.NotificationDTO;

public interface NotificationService {
	void sendSimpleMessage(String to, String subject, String text);
	void sendNotification(NotificationDTO notificationDTO);
}
