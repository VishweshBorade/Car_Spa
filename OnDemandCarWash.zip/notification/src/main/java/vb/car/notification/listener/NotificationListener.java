package vb.car.notification.listener;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import vb.car.notification.dto.NotificationDTO;
import vb.car.notification.service.NotificationService;

@Component
@RequiredArgsConstructor
@Slf4j
public class NotificationListener {

	private final NotificationService notificationService;
	
	@RabbitListener(queues = "notification.queue")
	public void listenNotificationQueue(NotificationDTO notificationDTO) {
		log.info("Received notification for : {}", notificationDTO.getTo());
		notificationService.sendNotification(notificationDTO);
	}
}
