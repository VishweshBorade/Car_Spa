package vb.car.notification.service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import vb.car.notification.dto.NotificationDTO;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationServiceImpl implements NotificationService {

	
	private final JavaMailSender javaMailSender;
	
	@Override
	public void sendSimpleMessage(String to, String subject, String text) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(to);
		message.setSubject(subject);
		message.setText(text);
		message.setFrom("carsspa.now@gmail.com");
		
		javaMailSender.send(message);

	}

	@Override
	public void sendNotification(NotificationDTO notificationDTO) {
		try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(notificationDTO.getTo());
            message.setSubject(notificationDTO.getSubject());
            message.setText(notificationDTO.getMessage());

            javaMailSender.send(message);

            log.info("Notification sent successfully to {}", notificationDTO.getTo());
        } catch (Exception e) {
            log.error("Failed to send notification to {}: {}", notificationDTO.getTo(), e.getMessage());
        }
		
	}

}
