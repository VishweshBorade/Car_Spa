package vb.car.notification.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import vb.car.notification.dto.NotificationDTO;
import vb.car.notification.service.NotificationService;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {
	
	private final NotificationService notificationService;
	
	
	@PostMapping("/send")
	public ResponseEntity<String> sendEmail(@Valid @RequestBody NotificationDTO notificationDTO){
		notificationService.sendSimpleMessage(
				notificationDTO.getTo(),
				notificationDTO.getSubject(),
				notificationDTO.getMessage()
		);
		return ResponseEntity.ok("Email sent successfully to " + notificationDTO.getTo());
	}
}
