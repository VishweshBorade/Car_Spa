package vb.car.bookingservice.event;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingCreatedEvent {
	
	private Long bookingId;
	private Long userId;
	private Double amount;
	private String paymentStatus;
}
