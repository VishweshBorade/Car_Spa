package vb.car.bookingservice.exception;

public class InvalidBookingStatusException extends RuntimeException{
	public InvalidBookingStatusException(String message) {
        super(message);
	}
}
