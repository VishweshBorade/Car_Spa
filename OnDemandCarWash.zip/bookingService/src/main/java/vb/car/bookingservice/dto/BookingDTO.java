package vb.car.bookingservice.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vb.car.bookingservice.entities.Booking;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class BookingDTO {
	@NotNull(message = "User ID is required")
	private Long userId;

	@NotNull(message = "Washer ID is required")
	private Long washerId;

	@NotBlank(message = "Car name is required")
	@Size(max = 50, message = "Car name must not exceed 50 characters")
	private String carName;

	@NotBlank(message = "Car model is required")
	@Size(max = 50, message = "Car model must not exceed 50 characters")
	private String carModel;

	@NotBlank(message = "Car license plate is required")
	@Pattern(regexp = "^[A-Z0-9-]+$", message = "Invalid license plate format")
	@Size(max = 20, message = "License plate must not exceed 20 characters")
	private String carLicensePlate;

	@NotNull(message = "Wash package is required")
	@Pattern(regexp = "Simple|Full-Wash|Semi-Premium|Premium")
	private Booking.WashPackage washPackage;

	@NotNull(message = "Scheduled time is required")
	private LocalDateTime scheduledTime;
	
	private Double price;
	
	@NotNull(message = "Status is required")
	@Pattern(regexp = "PENDING|CONFIRMED|COMPLETED|CANCELED", message = "Invalid status value")
	private Booking.status status;
}
