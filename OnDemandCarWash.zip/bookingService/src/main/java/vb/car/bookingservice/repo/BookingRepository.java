package vb.car.bookingservice.repo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import vb.car.bookingservice.entities.Booking;

public interface BookingRepository extends JpaRepository<Booking, Long> {
	  	List<Booking> findByUserId(Long userId);
	    List<Booking> findByWasherId(Long washerId);
	    List<Booking> findByStatus(String status);
	    List<Booking> findByScheduledTimeBetween(LocalDateTime start, LocalDateTime end);
	    
	    @Query("SELECT b FROM Booking b WHERE b.scheduledTime BETWEEN : startTime AND :endTime")
	    List<Booking> findBookingWithinTimeRange(@Param("startTime")LocalDateTime startTime, @Param("endTime")LocalDateTime endTime);
	    
	    @Query("SELECT b FROM Booking b WHERE b.status = 'PENDING'")
	    List<Booking> findAllPendingBookings();
}
