package vb.car.bookingservice.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "bookings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message = "User ID is required")
	private Long userId;

	@NotNull(message = "Washer ID is required")
	private Long washerId;

	@NotBlank(message = "Car name is required")
	@Size(max = 50, message = "Car name must not exceed 50 characters")
	private String carName;

	@NotBlank(message = "Car model is required")
	@Size(max = 50, message = "Car model must not exceed 50 characters")
	private String carModel;

	@NotBlank(message = "Car license plate is required")
	@Pattern(regexp = "^[A-Z0-9-]+$", message = "License plate must contain only uppercase letters, numbers, and dashes")
	@Size(max = 20, message = "License plate must not exceed 20 characters")
	private String carLicensePlate;

	@NotNull(message = "Wash package is required")
    @Enumerated(EnumType.STRING)
    private WashPackage washPackage;

	private Double price;

	@NotNull(message = "Scheduled time is required")
	private LocalDateTime scheduledTime;

	@NotNull(message = "Status is required")
    @Enumerated(EnumType.STRING)
    private status status;// Pending, Confirmed, Completed, Cancelled
	
	public enum WashPackage {
        SIMPLE, FULL_WASH, SEMI_PREMIUM, PREMIUM
    }

    public enum status {
        PENDING, CONFIRMED, COMPLETED, CANCELLED
    }
}
