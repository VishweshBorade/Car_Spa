package vb.car.bookingservice.config;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQCongif {
	
	@Value("${booking.queue.name}")
	@Autowired
	private String queue;
	
	@Value("${booking.exchange.name}")
	@Autowired
	private String exchange;
	
	@Value("${booking.routing.key}")
	@Autowired
	private String routingKey;

    @Bean
    Queue bookingQueue() {
		return new Queue(queue);
	}

    @Bean
    TopicExchange bookingExchange() {
		return new TopicExchange(exchange);
	}
	
	@Bean
	Binding binding() {
		return BindingBuilder.bind(bookingQueue())
				.to(bookingExchange())
				.with(routingKey);
	}
}
