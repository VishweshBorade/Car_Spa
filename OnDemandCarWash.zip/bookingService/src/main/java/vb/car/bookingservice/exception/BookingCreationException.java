package vb.car.bookingservice.exception;

public class BookingCreationException extends RuntimeException{
	 public BookingCreationException(String message) {
	        super(message);
	    }
}
