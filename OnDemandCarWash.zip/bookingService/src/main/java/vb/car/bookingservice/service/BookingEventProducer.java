package vb.car.bookingservice.service;

import java.util.logging.Logger;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import vb.car.bookingservice.event.BookingCreatedEvent;

@Service
@RequiredArgsConstructor
public class BookingEventProducer {
	
	private final RabbitTemplate rabbitTemplate;
	private static final Logger logger = Logger.getLogger(BookingEventProducer.class.getName());
	
	@Value("${booking.exchange.name}")
	private String exchange;
	
	@Value("${booking.routing.key}")
	private String routingKey;
	
	public void sendBookingEvent(BookingCreatedEvent event) {
		rabbitTemplate.convertAndSend(exchange,routingKey,event);
		logger.info("Event sent: "+event);
	}
}
