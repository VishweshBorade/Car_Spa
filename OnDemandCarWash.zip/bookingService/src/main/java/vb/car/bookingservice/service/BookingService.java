package vb.car.bookingservice.service;

import java.util.List;

import vb.car.bookingservice.dto.BookingDTO;
import vb.car.bookingservice.entities.Booking;

public interface BookingService {
	BookingDTO createBooking(BookingDTO bookingDTO);
    BookingDTO getBookingById(Long id);
    List<Booking> getAllBookings();
    List<Booking> getBookingsByUser(Long userId);
    List<Booking> getBookingsByWasher(Long washerId);
    BookingDTO updateBookingStatus(Long bookingId, String status);
    BookingDTO updateBooking(Long id, BookingDTO bookingDTO);
    void deleteBooking(Long id);
}
