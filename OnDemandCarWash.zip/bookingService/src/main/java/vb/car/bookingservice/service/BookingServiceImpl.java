package vb.car.bookingservice.service;
import java.util.List;

import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import vb.car.bookingservice.dto.BookingDTO;
import vb.car.bookingservice.entities.Booking;
import vb.car.bookingservice.entities.Booking.WashPackage;
import vb.car.bookingservice.entities.Booking.status;
import vb.car.bookingservice.exception.BookingCreationException;
import vb.car.bookingservice.exception.BookingNotFoundException;
import vb.car.bookingservice.exception.InvalidBookingStatusException;
import vb.car.bookingservice.repo.BookingRepository;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {
	
	private final BookingRepository bookingRepository;

    @Override
    public BookingDTO createBooking(BookingDTO bookingDTO) {
    	try {
        Booking booking = Booking.builder()
                .userId(bookingDTO.getUserId())
                .washerId(bookingDTO.getWasherId())
                .carName(bookingDTO.getCarName())
                .carModel(bookingDTO.getCarModel())
                .carLicensePlate(bookingDTO.getCarLicensePlate())
                .washPackage(bookingDTO.getWashPackage())
                .price(getPriceForPackage(bookingDTO.getWashPackage()))
                .scheduledTime(bookingDTO.getScheduledTime())
                .status(status.PENDING)
                .build();
        return convertToDTO(bookingRepository.save(booking));
    	}
    	catch (Exception e) {
    		throw new BookingCreationException("Error Creating booking: "+ e.getMessage());
    	}
    }
    
    private Double getPriceForPackage(WashPackage washPackage) {
        switch (washPackage) {
            case SIMPLE:
                return 10.0;
            case FULL_WASH:
                return 20.0;
            case SEMI_PREMIUM:
                return 30.0;
            case PREMIUM:
                return 50.0;
            default:
                throw new IllegalArgumentException("Invalid Wash Package");
        }
    }
    
    @Override
    public List<Booking> getAllBookings(){
    	return bookingRepository.findAll();
    }

    @Override
    public BookingDTO getBookingById(Long id) {
        return bookingRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new BookingNotFoundException("Booking with ID "+ id + "not found"));
    }

    @Override
    public List<Booking> getBookingsByUser(Long userId) {
        return bookingRepository.findByUserId(userId);
    }

    @Override
    public List<Booking> getBookingsByWasher(Long washerId) {
        return bookingRepository.findByWasherId(washerId);
    }

    @Override
    public BookingDTO updateBookingStatus(Long bookingId, String status) {
        if (!status.matches("PENDING|CONFIRMED|COMPLETED|CANCELLED")) {
            throw new InvalidBookingStatusException("Invalid booking status: " + status);
        }

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking with ID " + bookingId + " not found"));

        booking.setStatus(Booking.status.valueOf(status)); // Convert String to Enum
        return convertToDTO(bookingRepository.save(booking));
    }

    @Override
    public BookingDTO updateBooking(Long id, BookingDTO bookingDTO) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));
        
        booking.setCarName(bookingDTO.getCarName());
        booking.setCarModel(bookingDTO.getCarModel());
        booking.setCarLicensePlate(bookingDTO.getCarLicensePlate());
        booking.setWashPackage(bookingDTO.getWashPackage());
        booking.setPrice(getPriceForPackage(bookingDTO.getWashPackage()));
        booking.setScheduledTime(bookingDTO.getScheduledTime());
        
        return convertToDTO(bookingRepository.save(booking));
    }

    @Override
    public void deleteBooking(Long id) {
    	if(!bookingRepository.existsById(id)) {
    		throw new BookingNotFoundException("Booking with ID: "+id+" not found");
    	}
        bookingRepository.deleteById(id);
    }

    private BookingDTO convertToDTO(Booking booking) {
        return BookingDTO.builder()
                .userId(booking.getId())
                .userId(booking.getUserId())
                .washerId(booking.getWasherId())
                .carName(booking.getCarName())
                .carModel(booking.getCarModel())
                .carLicensePlate(booking.getCarLicensePlate())
                .washPackage(booking.getWashPackage())
                .price(booking.getPrice())
                .scheduledTime(booking.getScheduledTime())
                .status(booking.getStatus())
                .build();
    }
}
