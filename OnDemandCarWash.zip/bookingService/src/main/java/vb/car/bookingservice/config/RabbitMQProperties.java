package vb.car.bookingservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@ConfigurationProperties(prefix = "booking")
@Data
public class RabbitMQProperties {
	private String queue;
	private String exchange;
	private String routing;
}
