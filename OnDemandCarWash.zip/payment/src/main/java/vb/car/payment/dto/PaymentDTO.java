package vb.car.payment.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import vb.car.payment.entities.Payment.PaymentStatus;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentDTO {
	private Long bookingId;
	private Long userId;
	private BigDecimal amount;
	private String transactionId;
	private PaymentStatus status;
	private LocalDateTime createdAt;
	private String paymentMethodNonce;//Needed for Braintree

	
}
