package vb.car.payment.service;import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Result;
import com.braintreegateway.Transaction;
import com.braintreegateway.TransactionRequest;

import lombok.RequiredArgsConstructor;
import vb.car.payment.dto.PaymentDTO;
import vb.car.payment.entities.Payment;
import vb.car.payment.entities.Payment.PaymentStatus;
import vb.car.payment.exceptions.PaymentNotFoundException;
import vb.car.payment.exceptions.PaymentProcessingException;
import vb.car.payment.repo.PaymentRepository;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

	private final PaymentRepository paymentRepository;
	private final BraintreeGateway braintreeGateway;
	
	
	@Override
	public PaymentDTO createPayment(PaymentDTO paymentDTO) {
	    try {
	        TransactionRequest request = new TransactionRequest()
	            .amount(paymentDTO.getAmount())
	            .paymentMethodNonce(paymentDTO.getPaymentMethodNonce())
	            .options()
	                .submitForSettlement(true)
	                .done();

	        Result<Transaction> result = braintreeGateway.transaction().sale(request);

	        if (result.isSuccess()) {
	            Transaction transaction = result.getTarget();

	            Payment payment = Payment.builder()
	                .userId(paymentDTO.getUserId())
	                .bookingId(paymentDTO.getBookingId())
	                .amount(paymentDTO.getAmount())
	                .status(PaymentStatus.PENDING)
	                .transactionId(transaction.getId())
	                .paymentDate(LocalDateTime.now())
	                .createdAt(LocalDateTime.now())
	                .build();
	            
	            Payment saved = paymentRepository.save(payment);
	            return convertToDTO(saved);
	        } else {
	            throw new PaymentProcessingException("Transaction failed: " + result.getMessage());
	        }

	    } catch (Exception e) {
	        throw new PaymentProcessingException("Payment failed: " + e.getMessage());
	    }
	}

	
	@Override
	public PaymentDTO processPayment(PaymentDTO paymentDTO) {
		TransactionRequest request = new TransactionRequest()
				.amount(paymentDTO.getAmount())
				.paymentMethodNonce("fake-valid-nonce")
				.options()
				.submitForSettlement(true)
				.done();
		
		Result<Transaction> result = braintreeGateway.transaction().sale(request);
		
		if (!result.isSuccess()) {
			throw new PaymentProcessingException("Payment processing failed: " + result.getMessage());
		}
		
		Payment payment = Payment.builder()
				.bookingId(paymentDTO.getBookingId())
				.userId(paymentDTO.getUserId())
				.amount(paymentDTO.getAmount())
				.transactionId(result.isSuccess()?result.getTarget().getId():UUID.randomUUID().toString())
				.status(result.isSuccess()?PaymentStatus.SUCCESS:PaymentStatus.FAILED)
				.createdAt(LocalDateTime.now())
				.paymentDate(LocalDateTime.now())
				.build();
		paymentRepository.save(payment);
		
		return convertToDTO(payment);
	}

	@Override
	public PaymentDTO getPaymentByTransactionId(String transactionId) {
		Payment payment = paymentRepository.findByTransactionId(transactionId)
				.orElseThrow(()-> new PaymentNotFoundException("Transaction not found"));
		return convertToDTO(payment);
	}

	@Override
	public List<Payment> getAllPayments() {
		return paymentRepository.findAll();
	}
	@Override
	public List<Payment> getPaymentsByUser(Long userId) {
	    return paymentRepository.findByUserId(userId);
	}

	@Override
	public List<Payment> getPaymentsByBooking(Long bookingId) {
	    return paymentRepository.findByBookingId(bookingId);
	}

	@Override
	public List<Payment> getSuccessfullPayments() {
	    return paymentRepository.findSuccessfullPayments();
	}

	@Override
	public List<Payment> getFailedPayments() {
	    return paymentRepository.findFailedPayments();
	}

	@Override
	public Double getTotalRevenue() {
	    return paymentRepository.getTotalRevenue();
	}
	
//	@Override
//	public void initiatePaymentFromBooking(BookingCreatedEvent event) {
//		Payment payment = new Payment();
//		payment.setBookingId(event.getBookingId());
//		payment.setUserId(event.getUserId());
//		payment.setAmount(event.getAmount());
//		payment.setStatus(PaymentStatus.PENDING);
//		payment.setCreatedAt(LocalDateTime.now());
//		
//		paymentRepository.save(payment);
//		
//		
//	}

	
	 private PaymentDTO convertToDTO(Payment payment) {
	        return PaymentDTO.builder()
	                .bookingId(payment.getBookingId())
	                .userId(payment.getUserId())
	                .amount(payment.getAmount())
	                .transactionId(payment.getTransactionId())
	                .status(payment.getStatus())
	                .createdAt(payment.getCreatedAt())
	                .paymentMethodNonce(null)
	                .build();
	    }

	

}
