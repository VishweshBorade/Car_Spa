package vb.car.payment.exceptions;

public class PaymentProcessingException extends RuntimeException{
	public PaymentProcessingException(String message) {
		super(message);
	}
}
