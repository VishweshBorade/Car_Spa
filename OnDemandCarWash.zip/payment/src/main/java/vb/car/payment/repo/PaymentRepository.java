package vb.car.payment.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import vb.car.payment.entities.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long>{
	Optional<Payment> findByTransactionId(String transactionId);
	
	List<Payment> findByUserId(Long userId);
	
	List<Payment> findByBookingId(Long bookingId);
	
	@Query("SELECT p FROM Payment p WHERE p.status = 'SUCCESS'")
	List<Payment> findSuccessfullPayments();
	
	@Query("SELECT p FROM Payment p WHERE p.status = 'FAILED'")
	List<Payment> findFailedPayments();
	
	@Query("SELECT SUM(p.amount) FROM Payment p WHERE p.status = 'SUCCESS'")
	Double getTotalRevenue();
	
}
