package vb.car.payment.service;

import java.util.List;

import vb.car.payment.dto.PaymentDTO;
import vb.car.payment.entities.Payment;
import vb.car.payment.event.BookingCreatedEvent;

public interface PaymentService {
	
	PaymentDTO createPayment(PaymentDTO paymentDTO);
	PaymentDTO processPayment(PaymentDTO paymentDTO);
	PaymentDTO getPaymentByTransactionId(String transactionId);
	List<Payment> getAllPayments();
	List<Payment> getPaymentsByUser(Long userId);
	List<Payment> getPaymentsByBooking(Long bookingId);
	List<Payment> getSuccessfullPayments();
	List<Payment> getFailedPayments();
	public void initiatePaymentFromBooking(BookingCreatedEvent event);
	Double getTotalRevenue();

}
