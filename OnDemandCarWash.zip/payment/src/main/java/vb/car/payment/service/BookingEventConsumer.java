package vb.car.payment.service;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import vb.car.payment.event.BookingCreatedEvent;


@Component
public class BookingEventConsumer {
	
	@Autowired
	private PaymentService service;
	
	@RabbitListener(queues = "${booking.queue.name}")
	public void consume(BookingCreatedEvent event) {
		service.initiatePaymentFromBooking(event);
	}
	
}
