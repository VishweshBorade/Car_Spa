package vb.car.payment.entities;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="payments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private Long bookingId;
	
	@Column(nullable = false)
	private Long userId;
	
	@Column(nullable = false)
	private BigDecimal amount;
	
	@Column(nullable = false, unique = true)
	private String transactionId;
	
	@Enumerated(EnumType.STRING)
	private PaymentStatus status;
	
	@Column(nullable = false)
	private LocalDateTime createdAt;
	
	@Column(nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime paymentDate;

	
	public enum PaymentStatus {
		PENDING, SUCCESS, FAILED
	}
}
