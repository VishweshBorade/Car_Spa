package vb.car.payment.braintree;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Environment;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Configuration
@Component
@ConfigurationProperties(prefix = "braintree")
public class BraintreeConfig {

    private String merchantId;
    private String publicKey;
    private String privateKey;
    private String environment;

    @Bean
    BraintreeGateway braintreeGateway() {
        return new BraintreeGateway(
                environment.equalsIgnoreCase("sandbox") ? Environment.SANDBOX : Environment.PRODUCTION,
                merchantId,
                publicKey,
                privateKey
        );
    }
}
