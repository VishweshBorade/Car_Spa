package vb.car.admin.service;

import java.util.List;

import vb.car.admin.dto.AdminRequestDTO;
import vb.car.admin.dto.AdminResponseDTO;

public interface AdminService {
	
	AdminResponseDTO createAdmin(AdminRequestDTO requestDTO);
	AdminResponseDTO getAdminById(Long id);
	List<AdminResponseDTO> getAllAdmins();
	void deleteAdmin(Long id);
	Object updateAdmin(Long id, AdminRequestDTO dto);
	AdminResponseDTO getAdminByEmail(String email);

}
