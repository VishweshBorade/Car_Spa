package vb.car.admin.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import vb.car.admin.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {
	Optional<Admin> findByEmail(String email);
}
