package vb.car.admin.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import vb.car.admin.dto.AdminRequestDTO;
import vb.car.admin.dto.AdminResponseDTO;
import vb.car.admin.service.AdminService;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {
	
	private final AdminService service;
	
	@PostMapping("/create")
	public ResponseEntity<AdminResponseDTO> createAdmin(@RequestBody AdminRequestDTO requestDTO){
		return ResponseEntity.ok(service.createAdmin(requestDTO));
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<AdminResponseDTO> getAdminById(@PathVariable Long id){
		return ResponseEntity.ok(service.getAdminById(id));
	}
	
	@GetMapping("/get/{email}")
	public ResponseEntity<AdminResponseDTO> getAdminByEmail(@PathVariable String email){
		return ResponseEntity.ok(service.getAdminByEmail(email));
	}
	
	@GetMapping("/get/all")
	public ResponseEntity<List<AdminResponseDTO>> getAllAdmins(){
		return ResponseEntity.ok(service.getAllAdmins());
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Object> updateAdmin(@PathVariable Long id, @RequestBody AdminRequestDTO dto){
		return ResponseEntity.ok(service.updateAdmin(id, dto));
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteAdmin(@PathVariable Long id){
		service.deleteAdmin(id);
		return ResponseEntity.ok("Admin with ID: "+id+" deleted successfully.");
	}

}
