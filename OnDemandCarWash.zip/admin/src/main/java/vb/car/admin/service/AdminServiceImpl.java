package vb.car.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import vb.car.admin.dto.AdminRequestDTO;
import vb.car.admin.dto.AdminResponseDTO;
import vb.car.admin.entity.Admin;
import vb.car.admin.exception.AdminNotFoundException;
import vb.car.admin.repo.AdminRepository;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {
	
	private final AdminRepository repo;

	@Override
	public AdminResponseDTO createAdmin(AdminRequestDTO requestDTO) {
		Admin admin = Admin.builder()
				.name(requestDTO.getName())
				.email(requestDTO.getEmail())
				.password(requestDTO.getPassword())
				.build();
		return mapToDTO(repo.save(admin));
	}

	@Override
	public AdminResponseDTO getAdminById(Long id) {
		Admin admin = repo.findById(id)
				.orElseThrow(()-> new AdminNotFoundException("Admin not found with id: "+id));
		return mapToDTO(admin);
	}

	@Override
	public List<AdminResponseDTO> getAllAdmins() {
		return repo.findAll()
				.stream().map(this::mapToDTO).toList();
	}

	@Override
	public void deleteAdmin(Long id) {
		Admin admin = repo.findById(id)
				.orElseThrow(()-> new AdminNotFoundException("Admin not found with id: "+id));
		repo.delete(admin);
	}
	
	private AdminResponseDTO mapToDTO(Admin admin) {
		return AdminResponseDTO.builder()
				.id(admin.getId())
				.name(admin.getName())
				.email(admin.getEmail())
				.build();
	}

	@Override
	public Object updateAdmin(Long id, AdminRequestDTO dto) {
		Admin admin = repo.findById(id)
				.orElseThrow(()-> new AdminNotFoundException("Admin not found with ID: "+id));
		
		admin.setName(dto.getName());
		admin.setEmail(dto.getEmail());
		admin.setPassword(dto.getPassword());
		return mapToDTO(repo.save(admin));
	}

	@Override
	public AdminResponseDTO getAdminByEmail(String email) {
		Admin admin = repo.findByEmail(email)
				.orElseThrow(()-> new AdminNotFoundException("Admin not found with email: "+email));
		return mapToDTO(admin);
	}

}
