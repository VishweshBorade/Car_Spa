package vb.car.washer.exception;

public class WasherNotFoundException extends RuntimeException {
	public WasherNotFoundException(String message) {
		super(message);
	}
}
