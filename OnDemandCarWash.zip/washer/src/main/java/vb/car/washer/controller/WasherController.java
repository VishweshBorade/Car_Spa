package vb.car.washer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import vb.car.washer.dto.WasherDTO;
import vb.car.washer.service.WasherService;

@RestController
@RequestMapping("/api/washers")
@RequiredArgsConstructor
public class WasherController {
	
	@Autowired
	private final WasherService washerService;
	
	@PostMapping("/create")
	public ResponseEntity<WasherDTO> createWasher(@RequestBody WasherDTO washerDTO){
		return ResponseEntity.ok(washerService.createWasher(washerDTO));
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<WasherDTO> getWasherById(@PathVariable Long id){
		return ResponseEntity.ok(washerService.getWasherById(id));
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<WasherDTO>> getAllWashers(){
		return ResponseEntity.ok(washerService.getAllWashers());
	}
	
	@GetMapping("/location/{location}")
	public ResponseEntity<List<WasherDTO>> getWashersByLocation(@PathVariable String location){
		return ResponseEntity.ok(washerService.getWashersByLocation(location));
	}
	
	@GetMapping("/rating/{rating}")
	public ResponseEntity<List<WasherDTO>> getWashersByRating(@PathVariable Double rating){
		return ResponseEntity.ok(washerService.getWasherByRating(rating));
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<WasherDTO> updateWasher(@PathVariable Long id, @RequestBody WasherDTO washerDTO){
		return ResponseEntity.ok(washerService.updateWasher(id, washerDTO));
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteWasher(@PathVariable Long id){
		washerService.deleteWasher(id);
		return ResponseEntity.ok("Washer deleted successfully");
	}
}
