package vb.car.washer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import vb.car.washer.dto.WasherDTO;
import vb.car.washer.entities.Washer;
import vb.car.washer.exception.WasherNotFoundException;
import vb.car.washer.repo.WasherRepository;


@Service
@RequiredArgsConstructor
public class WasherServiceImpl implements WasherService {
	@Autowired
	private final WasherRepository washerRepo;
	
	@Override
	public WasherDTO createWasher(WasherDTO washerDTO) {
		Washer washer = Washer.builder()
				.name(washerDTO.getName())
				.email(washerDTO.getEmail())
				.phone(washerDTO.getPhone())
				.location(washerDTO.getLocation())
				.rating(washerDTO.getRating())
				.build();
		Washer savedWasher = washerRepo.save(washer);
		return convertToDTO(savedWasher);
		
	}
	
	private static final String WASHER_NOT_FOUND_MSG = "Washer with ID %d not found";

	@Override
	public WasherDTO getWasherById(Long id) {
		return washerRepo.findById(id)
				.map(this::convertToDTO)
				.orElseThrow(()-> new WasherNotFoundException(String.format(WASHER_NOT_FOUND_MSG, id)));
	}

	@Override
	public List<WasherDTO> getAllWashers() {
		return washerRepo.findAll().stream().map(this::convertToDTO).toList();
	}

	@Override
	public List<WasherDTO> getWashersByLocation(String location) {
		return washerRepo.findByLocation(location).stream().map(this::convertToDTO).toList();
	}

	@Override
	public List<WasherDTO> getWasherByRating(Double rating) {
		return washerRepo.findByRatingGreaterThanEqual(rating).stream().map(this::convertToDTO).toList();
	}

	@Override
	public WasherDTO updateWasher(Long id, WasherDTO washerDTO) {
		Washer washer = washerRepo.findById(id)
				.orElseThrow(()-> new WasherNotFoundException(String.format(WASHER_NOT_FOUND_MSG, id)));
		washer.setName(washerDTO.getName());
		washer.setEmail(washerDTO.getEmail());
		washer.setPhone(washerDTO.getPhone());
		washer.setLocation(washerDTO.getLocation());
		washer.setRating(washerDTO.getRating());
		
		return convertToDTO(washerRepo.save(washer));
	}

	@Override
	public void deleteWasher(Long id) {
		Washer washer = washerRepo.findById(id)
				.orElseThrow(()-> new WasherNotFoundException(String.format(WASHER_NOT_FOUND_MSG, id)));
		washerRepo.delete(washer);
	}
	
	private WasherDTO convertToDTO(Washer washer) {
        return WasherDTO.builder()
                .id(washer.getId())
                .name(washer.getName())
                .email(washer.getEmail())
                .phone(washer.getPhone())
                .location(washer.getLocation())
                .rating(washer.getRating())
                .build();
    }
}
