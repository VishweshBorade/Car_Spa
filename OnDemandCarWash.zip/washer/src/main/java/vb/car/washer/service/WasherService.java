package vb.car.washer.service;

import java.util.List;

import vb.car.washer.dto.WasherDTO;

public interface WasherService {
	WasherDTO createWasher(WasherDTO washerDTO);
	WasherDTO getWasherById(Long id);
	List<WasherDTO> getAllWashers();
	List<WasherDTO> getWashersByLocation(String location);
	List<WasherDTO> getWasherByRating(Double rating);
	WasherDTO updateWasher(Long id, WasherDTO washerDTO);
	void deleteWasher(Long id);
}
