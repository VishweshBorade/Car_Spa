package vb.car.washer.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="washers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Washer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Name is required")
	private String name;
	
	@Email
	@NotBlank(message="Email is required")
	private String email;
	
	@NotBlank(message="Phone number is required")
	@Pattern(regexp="^\\d{10}$",message="Invalid phone number format")
	private String phone;
	
	@NotBlank(message="Location is required")
	private String location;
	
	@NotNull(message = "Rating is required")
	private Double rating;
	
}