package vb.car.washer.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vb.car.washer.entities.Washer;

@Repository
public interface WasherRepository extends JpaRepository<Washer, Long>{
	List<Washer> findByLocation(String location);
	List<Washer> findByRatingGreaterThanEqual(Double rating);
	
	@Query("SELECT w FROM Washer w WHERE LOWER(w.name) = LOWER(:name)")
	List<Washer> findByName(String name);
	
	@Query("SELECT w FROM Washer w WHERE w.location = :location ORDER BY w.rating DESC")
	List<Washer> findTopRatedWashersInLocation(String location);
}
