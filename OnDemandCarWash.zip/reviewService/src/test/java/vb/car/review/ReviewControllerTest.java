package vb.car.review;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import vb.car.review.controller.ReviewController;
import vb.car.review.dto.ReviewRequestDTO;
import vb.car.review.dto.ReviewResponseDTO;
import vb.car.review.exception.ReviewNotFoundException;
import vb.car.review.service.ReviewService;
import static org.hamcrest.Matchers.hasSize;


@WebMvcTest(ReviewController.class)
class ReviewControllerTest {

	 @Autowired
	    private MockMvc mockMvc;

	    @MockBean
	    private ReviewService reviewService;

	    @Autowired
	    private ObjectMapper objectMapper;

	    @Test
	    void createReview_success() throws Exception {
	        ReviewRequestDTO request = new ReviewRequestDTO(1L, 2L, "Great wash", 5);
	        ReviewResponseDTO response = new ReviewResponseDTO(1L, 1L, 2L, "Great wash", 5);

	        Mockito.when(reviewService.createReview(any())).thenReturn(response);

	        mockMvc.perform(post("/reviews/create")
	                        .contentType(MediaType.APPLICATION_JSON)
	                        .content(objectMapper.writeValueAsString(request)))
	                .andExpect(status().isCreated())
	                .andExpect(jsonPath("$.comment").value("Great wash"))
	                .andExpect(jsonPath("$.rating").value(5));
	    }

	    @Test
	    void createReview_invalidRequest() throws Exception {
	        ReviewRequestDTO invalid = new ReviewRequestDTO(); // empty

	        mockMvc.perform(post("/reviews/create")
	                        .contentType(MediaType.APPLICATION_JSON)
	                        .content(objectMapper.writeValueAsString(invalid)))
	                .andExpect(status().isBadRequest())
	                .andExpect(jsonPath("$.error").value("VALIDATION_ERROR"));
	    }

	    @Test
	    void getReviewById_found() throws Exception {
	        ReviewResponseDTO response = new ReviewResponseDTO(1L, 1L, 2L, "Solid work", 4);
	        Mockito.when(reviewService.getReviewById(1L)).thenReturn(response);

	        mockMvc.perform(get("/reviews/id/1"))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$.comment").value("Solid work"))
	                .andExpect(jsonPath("$.rating").value(4));
	    }

	    @Test
	    void getReviewById_notFound() throws Exception {
	        Mockito.when(reviewService.getReviewById(999L)).thenThrow(new ReviewNotFoundException("Not found"));

	        Long nonExistentId = 999L;
	        mockMvc.perform(get("/reviews/id/{id}", nonExistentId))
	                .andExpect(status().isNotFound())
	                .andExpect(jsonPath("$.error").value("REVIEW_NOT_FOUND"))
	                .andExpect(jsonPath("$.message").value("Not found"));
	    }

	    @Test
	    void getAllReviews() throws Exception {
	        List<ReviewResponseDTO> list = List.of(
	                new ReviewResponseDTO(1L, 1L, 2L, "Nice", 4),
	                new ReviewResponseDTO(2L, 1L, 2L, "Ok", 3)
	        );

	        Mockito.when(reviewService.getAllReviews()).thenReturn(list);

	        mockMvc.perform(get("/reviews/all"))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$.length()").value(2));
	    }

	    @Test
	    void getReviewsByUser() throws Exception {
	        List<ReviewResponseDTO> list = List.of(
	                new ReviewResponseDTO(1L, 1L, 2L, "Decent", 3)
	        );

	        Mockito.when(reviewService.getReviewsByUserId(1L)).thenReturn(list);

	        mockMvc.perform(get("/reviews/user/1"))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$[0].userId").value(1));
	    }

	    @Test
	    void getReviewsByRating() throws Exception {
	        List<ReviewResponseDTO> list = List.of(
	                new ReviewResponseDTO(1L, 1L, 2L, "Excellent", 5)
	        );

	        Mockito.when(reviewService.getReviewsByRating(5)).thenReturn(list);

	        mockMvc.perform(get("/reviews/rating/5"))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$[0].rating").value(5));
	    }

	    @Test
	    void deleteReview_success() throws Exception {
	        doNothing().when(reviewService).deleteReview(1L);

	        mockMvc.perform(delete("/reviews/delete/1"))
	                .andExpect(status().isNoContent());
	    }
}
