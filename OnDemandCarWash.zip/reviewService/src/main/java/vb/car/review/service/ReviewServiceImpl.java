package vb.car.review.service;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import vb.car.review.dto.ReviewRequestDTO;
import vb.car.review.dto.ReviewResponseDTO;
import vb.car.review.entity.Review;
import vb.car.review.exception.ReviewNotFoundException;
import vb.car.review.repo.ReviewRepository;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

	private final ReviewRepository reviewRepository;
	
	@Override
	public ReviewResponseDTO createReview(ReviewRequestDTO dto) {
		Review review = Review.builder()
				.userId(dto.getUserId())
				.bookingId(dto.getBookingId())
				.comment(dto.getComment())
				.rating(dto.getRating())
				.build();
		return mapToResponse(reviewRepository.save(review));
	}

	@Override
	public List<ReviewResponseDTO> getAllReviews() {
		return reviewRepository.findAll().stream().map(this::mapToResponse).toList();
	}

	@Override
	public ReviewResponseDTO getReviewById(Long id) {
		Review review = reviewRepository.findById(id)
				.orElseThrow(()-> new ReviewNotFoundException("Review not found"));
		return mapToResponse(review);
	}

	@Override
	public List<ReviewResponseDTO> getReviewsByUserId(Long userId) {
		return reviewRepository.findByUserId(userId).stream().map(this::mapToResponse).toList();
	}

	@Override
	public List<ReviewResponseDTO> getReviewsByRating(int rating) {
		return reviewRepository.findByRating(rating).stream().map(this::mapToResponse).toList();
	}
	
	@Override
	public ReviewResponseDTO updateReview(Long id, ReviewRequestDTO dto) {
	    Review review = reviewRepository.findById(id)
	            .orElseThrow(() -> new ReviewNotFoundException("Review not found with id: " + id));

	    review.setUserId(dto.getUserId());
	    review.setBookingId(dto.getBookingId());
	    review.setComment(dto.getComment());
	    review.setRating(dto.getRating());

	    Review updated = reviewRepository.save(review);
	    return mapToResponse(updated);
	}


	@Override
	public void deleteReview(Long id) {
		if(!reviewRepository.existsById(id)) {
			throw new ReviewNotFoundException("Cannot delete. Review with ID "+id+" not found");
		}
		reviewRepository.deleteById(id);

	}
	private ReviewResponseDTO mapToResponse(Review review) {
        return ReviewResponseDTO.builder()
                .id(review.getId())
                .userId(review.getUserId())
                .bookingId(review.getBookingId())
                .comment(review.getComment())
                .rating(review.getRating())
                .build();
    }

}
