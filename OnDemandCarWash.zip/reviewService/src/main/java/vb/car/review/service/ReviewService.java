package vb.car.review.service;

import java.util.List;

import vb.car.review.dto.ReviewRequestDTO;
import vb.car.review.dto.ReviewResponseDTO;

public interface ReviewService {
	ReviewResponseDTO createReview(ReviewRequestDTO dto);
    List<ReviewResponseDTO> getAllReviews();
    ReviewResponseDTO getReviewById(Long id);
    List<ReviewResponseDTO> getReviewsByUserId(Long userId);
    List<ReviewResponseDTO> getReviewsByRating(int rating);
    ReviewResponseDTO updateReview(Long id, ReviewRequestDTO dto);
    void deleteReview(Long id);
    
}
