package vb.car.cars.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CarResponseDTO {
	
	private Long id;
    private Long userId;
    private String brand;
    private String model;
    private String type;
    private String registrationNumber;
    private Integer year;
}
