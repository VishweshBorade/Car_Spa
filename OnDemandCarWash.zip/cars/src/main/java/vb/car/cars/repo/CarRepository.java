package vb.car.cars.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import vb.car.cars.entity.Car;

@Repository
public interface CarRepository extends JpaRepository<Car, Long> {
	
	List<Car> findByUserId(Long userId);
	
	List<Car> findByType(String type);
	
	List<Car> findByUserIdAndType(Long userId, String type);
	
}
