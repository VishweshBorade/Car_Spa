package vb.car.cars.service;

import java.util.List;

import vb.car.cars.dto.CarRequestDTO;
import vb.car.cars.dto.CarResponseDTO;

public interface CarService {
	
	CarResponseDTO addCar(CarRequestDTO carRequestDTO);
	
	List<CarResponseDTO> getAllCars();
	
	CarResponseDTO getCarById(Long id);
	
	List<CarResponseDTO> getCarsByUserId(Long userId);
	
	List<CarResponseDTO> getCarsByType(String type);
	
	List<CarResponseDTO> getCarsByUserIdAndType(Long userId, String type);
	
	CarResponseDTO updateCar(Long id, CarRequestDTO carRequestDTO);
	
	void deleteCar(Long id);
}
