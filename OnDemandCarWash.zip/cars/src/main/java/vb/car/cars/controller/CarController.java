package vb.car.cars.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import vb.car.cars.dto.CarRequestDTO;
import vb.car.cars.dto.CarResponseDTO;
import vb.car.cars.service.CarService;

@RestController
@RequestMapping("/api/cars")
@RequiredArgsConstructor
public class CarController {
	
	private final CarService carService;
	
	@PostMapping("/create")
	public ResponseEntity<CarResponseDTO> createCar(@Valid @RequestBody CarRequestDTO carRequestDTO){
		return ResponseEntity.ok(carService.addCar(carRequestDTO));
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<CarResponseDTO> getCarById(@PathVariable Long id){
		return ResponseEntity.ok(carService.getCarById(id));
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<CarResponseDTO>> getAllCars(){
		return ResponseEntity.ok(carService.getAllCars());
	}
	
	@GetMapping("/user/{userId}")
	public ResponseEntity<List<CarResponseDTO>> getCarsByUserId(@PathVariable Long userId){
		return ResponseEntity.ok(carService.getCarsByUserId(userId));
	}
	
	@GetMapping("/type/{type}")
	public ResponseEntity<List<CarResponseDTO>> getCarsByType(@PathVariable String type){
		return ResponseEntity.ok(carService.getCarsByType(type));
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<CarResponseDTO> updateCar(@PathVariable Long id, @Valid @RequestBody CarRequestDTO carRequestDTO){
		return ResponseEntity.ok(carService.updateCar(id, carRequestDTO));
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteCar(@PathVariable Long id){
		carService.deleteCar(id);
		return ResponseEntity.ok("Car with ID " + id + " deleted successfully");
	}
}
