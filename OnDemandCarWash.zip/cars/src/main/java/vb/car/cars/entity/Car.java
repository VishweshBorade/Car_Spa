package vb.car.cars.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "cars")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Car {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "User ID is required")
	private Long userId;
	
	@NotBlank(message = "Car brand is required")
	private String brand;
	
	@NotBlank(message = "Car model is required")
	private String model;
	
	@NotBlank(message = "Car type is required")
	private String type;
	
	@NotBlank(message = "Car registration number is required")
	@Column(unique = true)
	private String registrationNumber;
	
	@NotNull(message = "Year of manufacture is required")
	private Integer year;
	
}
