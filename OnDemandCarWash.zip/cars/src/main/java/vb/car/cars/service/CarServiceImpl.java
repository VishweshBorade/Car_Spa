package vb.car.cars.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import vb.car.cars.dto.CarRequestDTO;
import vb.car.cars.dto.CarResponseDTO;
import vb.car.cars.entity.Car;
import vb.car.cars.exception.CarNotFoundException;
import vb.car.cars.repo.CarRepository;

@Service
@RequiredArgsConstructor
@Slf4j
public class CarServiceImpl implements CarService {

	
	private final CarRepository carRepository;
	
	@Override
	public CarResponseDTO addCar(CarRequestDTO dto) {
		Car car = mapToEntity(dto);
		Car saved = carRepository.save(car);
		log.info("Car added: {}",saved.getId());
		return mapToDTO(saved);
	}

	@Override
	public List<CarResponseDTO> getAllCars() {
		return carRepository.findAll()
				.stream()
				.map(this::mapToDTO).toList();
	}

	@Override
	public CarResponseDTO getCarById(Long id) {
		Car car = carRepository.findById(id)
				.orElseThrow(()-> new CarNotFoundException("Car not found with ID: "+ id));
		return mapToDTO(car);
	}

	@Override
	public List<CarResponseDTO> getCarsByUserId(Long userId) {
		return carRepository.findByUserId(userId)
				.stream().map(this::mapToDTO).toList();
	}

	@Override
	public List<CarResponseDTO> getCarsByType(String type) {
		return carRepository.findByType(type)
				.stream().map(this::mapToDTO).toList();
	}

	@Override
	public List<CarResponseDTO> getCarsByUserIdAndType(Long userId, String type) {
		return carRepository.findByUserIdAndType(userId, type)
				.stream().map(this::mapToDTO)
				.toList();
	}

	@Override
	public CarResponseDTO updateCar(Long id, CarRequestDTO dto) {
		Car car = carRepository.findById(id)
				.orElseThrow(()-> new CarNotFoundException("Car not found with ID: " + id));
		
		car.setBrand(dto.getBrand());
		car.setModel(dto.getModel());
		car.setType(dto.getType());
		car.setRegistrationNumber(dto.getRegistrationNumber());
		car.setYear(dto.getYear());
		car.setUserId(dto.getUserId());
		
		Car updated = carRepository.save(car);
		log.info("Car updated: {}", id);
		
		return mapToDTO(updated);
	}

	@Override
	public void deleteCar(Long id) {
		if(!carRepository.existsById(id)) {
			throw new CarNotFoundException("Car not found with ID: "+ id);
		}
		carRepository.deleteById(id);
		log.info("Car deleted: {}", id);
	}
	
    private CarResponseDTO mapToDTO(Car car) {
        return CarResponseDTO.builder()
                .id(car.getId())
                .userId(car.getUserId())
                .brand(car.getBrand())
                .model(car.getModel())
                .type(car.getType())
                .registrationNumber(car.getRegistrationNumber())
                .year(car.getYear())
                .build();
    }

    private Car mapToEntity(CarRequestDTO dto) {
        return Car.builder()
                .userId(dto.getUserId())
                .brand(dto.getBrand())
                .model(dto.getModel())
                .type(dto.getType())
                .registrationNumber(dto.getRegistrationNumber())
                .year(dto.getYear())
                .build();
    }

}
