package vb.car.cars.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import vb.car.cars.dto.CarRequestDTO;
import vb.car.cars.dto.CarResponseDTO;
import vb.car.cars.entity.Car;
import vb.car.cars.exception.CarNotFoundException;
import vb.car.cars.repo.CarRepository;
import vb.car.cars.service.CarServiceImpl;

class CarServiceImplTest {
	
	@Mock
	private CarRepository carRepository;
	
	@InjectMocks
	private CarServiceImpl carService;
	
	private Car car;
	private CarRequestDTO carRequest;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		
		car = Car.builder()
				.id(1L)
				.userId(101L)
				.brand("Toyota")
				.model("Corolla")
				.type("Sedan")
				.registrationNumber("ABC1234")
				.year(2020)
				.build();
		
		carRequest = CarRequestDTO.builder()
				.userId(101L)
				.brand("Toyota")
				.model("Corolla")
				.type("Sedan")
				.registrationNumber("ABC1234")
				.year(2020)
				.build();
	}
	
	@Test
	void testAddCar() {
		
		when(carRepository.save(any(Car.class))).thenReturn(car);
		
		CarResponseDTO response = carService.addCar(carRequest);
		
		assertNotNull(response);
		assertEquals("Toyota", response.getBrand());
		verify(carRepository, times(1)).save(any(Car.class));
	}
	
	@Test
	void testGetAllCars() {
		
		when(carRepository.findAll()).thenReturn(Arrays.asList(car));
		
		List<CarResponseDTO> responseList = carService.getAllCars();
		
		assertEquals(1, responseList.size());
		assertEquals("Toyota",responseList.get(0).getBrand());
		verify(carRepository, times(1)).findAll();
	}
	
	@Test
	void testGetCarById_Success() {
		when(carRepository.findById(1L)).thenReturn(Optional.of(car));
		
		CarResponseDTO response = carService.getCarById(1L);
		
		assertNotNull(response);
		assertEquals("Toyota", response.getBrand());
		verify(carRepository, times(1)).findById(1L);
	}
	
	@Test
	void testGetCarById_NotFound() {
		when(carRepository.findById(2L)).thenReturn(Optional.empty());
		
		assertThrows(CarNotFoundException.class, ()->carService.getCarById(2L));
		verify(carRepository, times(1)).findById(2L);
	}
}
