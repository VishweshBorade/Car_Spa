package vb.car.cars.tests;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;


import vb.car.cars.controller.CarController;
import vb.car.cars.dto.CarRequestDTO;
import vb.car.cars.dto.CarResponseDTO;
import vb.car.cars.service.CarService;

@WebMvcTest(CarController.class)
class CarControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
		
	@MockBean
	private CarService carService;
	
	private CarResponseDTO carResponse;
	
	@BeforeEach
	void setUp() {
		CarRequestDTO.builder()
				.userId(101L)
				.brand("Toyota")
				.model("Corolla")
				.type("Sedan")
				.registrationNumber("ABC1234")
				.year(2020)
				.build();
		
		carResponse = CarResponseDTO.builder()
				.id(1L)
				.userId(101L)
				.brand("Toyota")
				.model("Corolla")
				.type("Sedan")
				.registrationNumber("ABC1234")
				.year(2020)
				.build();
		
	}
	
	@Test
	void testGetAllCars() throws Exception {
		when(carService.getAllCars()).thenReturn(Arrays.asList(carResponse));
		
		
		mockMvc.perform(get("/api/cars/all"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.size()").value(1))
			.andExpect(jsonPath("$[0].model").value("Corolla"));
	}
	
	@Test
	void testGetCarById() throws Exception{
		when(carService.getCarById(1L)).thenReturn(carResponse);
		
		mockMvc.perform(get("/api/cars/get/1"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.id").value(1L))
			.andExpect(jsonPath("$.type").value("Sedan"));
	}



}
